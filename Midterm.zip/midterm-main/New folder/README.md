# Simple Banking System (Laravel)

This workspace contains Laravel implementation files for the laboratory assignment, targeting Laravel 11 or 12 and PHP 8.2+. It is an implementation overlay, not a complete Laravel scaffold; create a standard Laravel application first, then copy in the listed files. The workspace did not contain an existing Laravel scaffold, and PHP/Composer are not installed in the current environment, so migrations and PHP tests could not be run here.

## Install into a Laravel application

1. Create a Laravel 11/12 application with authentication enabled, or copy these files into an existing authenticated Laravel application.
2. Copy the `app`, `database`, `routes`, and `resources` files into the Laravel project. Register `App\Providers\AppServiceProvider` in the application's provider list if it is not already registered.
3. Ensure the standard Laravel `users` migration exists; account records belong to users, and the routes require the `auth` middleware.
4. Configure the database, mail transport, and a queue worker. The low-balance email is queued and scheduled after the database transaction commits.
5. Run `php artisan migrate`, create at least one account for an authenticated user, then visit `/dashboard`.

The dashboard polls the authenticated user's selected account every five seconds. Deposits, withdrawals, and transfers are submitted with CSRF protection. A transfer is represented by a linked debit and credit transaction, and both entries plus their balance changes are committed atomically.

The answers requested for the PDF are in HTML comments in `public/index.html`.

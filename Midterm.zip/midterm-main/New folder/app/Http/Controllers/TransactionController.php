<?php

namespace App\Http\Controllers;

use App\Models\Account;
use App\Models\BankTransaction;
use App\Support\Money;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class TransactionController extends Controller
{
    public function index(Request $request): View
    {
        $accounts = $request->user()->accounts()
            ->with(['transactions' => fn ($query) => $query->latest()->limit(20)])
            ->get();

        return view('dashboard', compact('accounts'));
    }

    public function create(Request $request): View
    {
        $accounts = $request->user()->accounts()->get();

        return view('dashboard', compact('accounts'));
    }

    public function store(Request $request): JsonResponse|RedirectResponse
    {
        $userId = $request->user()->getAuthIdentifier();

        $validated = Validator::make($request->all(), [
            'account_id' => [
                'required',
                'integer',
                Rule::exists('accounts', 'id')->where('user_id', $userId),
            ],
            'type' => ['required', Rule::in(['deposit', 'withdrawal', 'transfer'])],
            'amount' => ['required', 'numeric', 'gt:0', 'decimal:0,2', 'max:9999999999999.99'],
            'destination_account_id' => [
                Rule::requiredIf($request->input('type') === 'transfer'),
                'nullable',
                'integer',
                Rule::exists('accounts', 'id')->where('user_id', $userId),
                'different:account_id',
            ],
        ], [
            'destination_account_id.required' => 'Choose a destination account for the transfer.',
            'destination_account_id.different' => 'The destination must be different from the source account.',
        ])->validate();

        $amount = Money::fromCents(Money::toCents((string) $validated['amount']));

        $transactions = DB::transaction(function () use ($validated, $amount): array {
            $accountIds = [(int) $validated['account_id']];

            if ($validated['type'] === 'transfer') {
                $accountIds[] = (int) $validated['destination_account_id'];
            }

            sort($accountIds);

            $lockedAccounts = Account::query()
                ->whereIn('id', $accountIds)
                ->orderBy('id')
                ->lockForUpdate()
                ->get()
                ->keyBy('id');

            $source = $lockedAccounts->get((int) $validated['account_id']);
            $destination = $validated['type'] === 'transfer'
                ? $lockedAccounts->get((int) $validated['destination_account_id'])
                : null;

            if ($source === null || ($validated['type'] === 'transfer' && $destination === null)) {
                throw ValidationException::withMessages([
                    'account_id' => 'One or more selected accounts are unavailable.',
                ]);
            }

            if (
                in_array($validated['type'], ['withdrawal', 'transfer'], true)
                && Money::toCents((string) $source->balance) < Money::toCents($amount)
            ) {
                throw ValidationException::withMessages([
                    'amount' => 'The account does not have enough funds.',
                ]);
            }

            if ($validated['type'] !== 'transfer') {
                return [
                    BankTransaction::create([
                        'account_id' => $source->id,
                        'type' => $validated['type'],
                        'amount' => $amount,
                    ]),
                ];
            }

            $reference = (string) Str::uuid();

            return [
                BankTransaction::create([
                    'account_id' => $source->id,
                    'transfer_reference' => $reference,
                    'type' => 'transfer_out',
                    'amount' => $amount,
                ]),
                BankTransaction::create([
                    'account_id' => $destination->id,
                    'transfer_reference' => $reference,
                    'type' => 'transfer_in',
                    'amount' => $amount,
                ]),
            ];
        }, attempts: 3);

        if ($request->expectsJson()) {
            $accountIds = collect($transactions)->pluck('account_id')->unique();

            return response()->json([
                'message' => 'Transaction completed successfully.',
                'transactions' => $transactions,
                'accounts' => Account::query()
                    ->whereIn('id', $accountIds)
                    ->get(['id', 'balance', 'low_balance_threshold']),
            ], 201);
        }

        return redirect()->route('transactions.index')
            ->with('status', 'Transaction completed successfully.');
    }

    public function summary(Request $request, Account $account): JsonResponse
    {
        abort_unless($account->user_id === $request->user()->getAuthIdentifier(), 404);

        return response()->json([
            'id' => $account->id,
            'balance' => $account->balance,
            'low_balance' => (float) $account->balance <= (float) $account->low_balance_threshold,
            'low_balance_threshold' => $account->low_balance_threshold,
            'transactions' => $account->transactions()
                ->latest()
                ->limit(20)
                ->get(['id', 'type', 'amount', 'transfer_reference', 'created_at']),
        ]);
    }
}

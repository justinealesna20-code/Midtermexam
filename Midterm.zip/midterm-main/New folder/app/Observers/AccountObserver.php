<?php

namespace App\Observers;

use App\Models\BankTransaction;
use App\Models\User;
use App\Notifications\LowBalanceNotification;
use App\Support\Money;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class AccountObserver
{
    public function created(BankTransaction $transaction): void
    {
        $account = $transaction->account()
            ->lockForUpdate()
            ->firstOrFail();

        $previousBalance = Money::toCents((string) $account->balance);
        $amount = Money::toCents((string) $transaction->amount);

        if ($amount <= 0) {
            throw ValidationException::withMessages([
                'amount' => 'Transaction amounts must be greater than zero.',
            ]);
        }

        $newBalance = match ($transaction->type) {
            'deposit', 'transfer_in' => $previousBalance + $amount,
            'withdrawal', 'transfer_out' => $previousBalance - $amount,
            default => throw ValidationException::withMessages([
                'type' => 'The transaction type is not supported.',
            ]),
        };

        if ($newBalance < 0) {
            throw ValidationException::withMessages([
                'amount' => 'The account does not have enough funds.',
            ]);
        }

        $account->forceFill(['balance' => Money::fromCents($newBalance)])
            ->saveQuietly();

        if (
            $previousBalance > Money::toCents((string) $account->low_balance_threshold)
            && $newBalance <= Money::toCents((string) $account->low_balance_threshold)
        ) {
            $userId = $account->user_id;
            $balance = Money::fromCents($newBalance);
            $threshold = (string) $account->low_balance_threshold;

            DB::afterCommit(static function () use ($userId, $balance, $threshold): void {
                $user = User::query()->find($userId);

                if ($user !== null) {
                    $user->notify(new LowBalanceNotification($balance, $threshold));
                }
            });
        }
    }
}

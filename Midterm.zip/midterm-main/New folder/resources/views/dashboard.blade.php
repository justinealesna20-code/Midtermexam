<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Banking Dashboard</title>
    <style>
        body { font: 16px system-ui, sans-serif; margin: 2rem auto; max-width: 900px; padding: 0 1rem; color: #172033; }
        section, form { border: 1px solid #d8deea; border-radius: 8px; margin: 1rem 0; padding: 1rem; }
        label { display: block; margin: .75rem 0 .25rem; }
        input, select, button { font: inherit; padding: .5rem; }
        #alert { color: #a32626; font-weight: 700; }
        li { margin: .4rem 0; }
    </style>
</head>
<body>
    <h1>Banking Dashboard</h1>

    @if (session('status'))
        <p role="status">{{ session('status') }}</p>
    @endif

    @if ($errors->any())
        <ul role="alert">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    @endif

    @if ($accounts->isEmpty())
        <p>No accounts are associated with your user yet.</p>
    @else
        <label for="account-picker">Account</label>
        <select id="account-picker">
            @foreach ($accounts as $account)
                <option value="{{ $account->id }}">
                    Account #{{ $account->id }} — ${{ $account->balance }}
                </option>
            @endforeach
        </select>

        <section aria-live="polite">
            <h2>Balance: $<span id="balance">--</span></h2>
            <p id="alert" hidden>Your balance is at or below your alert threshold.</p>
            <p>Alert threshold: $<span id="threshold">--</span></p>
            <h3>Recent transactions</h3>
            <ul id="transactions"></ul>
            <p id="poll-error" role="status"></p>
        </section>

        <form id="transaction-form" action="{{ route('transactions.store') }}" method="post">
            @csrf
            <h2>Make a transaction</h2>
            <input type="hidden" name="account_id" id="form-account-id" value="{{ $accounts->first()->id }}">

            <label for="type">Type</label>
            <select name="type" id="type" required>
                <option value="deposit">Deposit</option>
                <option value="withdrawal">Withdrawal</option>
                <option value="transfer">Transfer</option>
            </select>

            <label for="amount">Amount</label>
            <input type="number" id="amount" name="amount" min="0.01" max="9999999999999.99" step="0.01" required>

            <div id="destination-wrap" hidden>
                <label for="destination_account_id">Destination account</label>
                <select name="destination_account_id" id="destination_account_id">
                    @foreach ($accounts as $account)
                        <option value="{{ $account->id }}">Account #{{ $account->id }}</option>
                    @endforeach
                </select>
            </div>
            <button type="submit">Submit transaction</button>
            <p id="form-message" role="status"></p>
        </form>
    @endif

    <script>
        (() => {
            const picker = document.querySelector('#account-picker');
            if (!picker) return;

            const balance = document.querySelector('#balance');
            const threshold = document.querySelector('#threshold');
            const alert = document.querySelector('#alert');
            const list = document.querySelector('#transactions');
            const pollError = document.querySelector('#poll-error');
            const type = document.querySelector('#type');
            const destinationWrap = document.querySelector('#destination-wrap');
            const destination = document.querySelector('#destination_account_id');
            const csrf = document.querySelector('meta[name="csrf-token"]').content;

            async function refresh() {
                try {
                    const response = await fetch(`/api/accounts/${picker.value}/summary`, {
                        headers: { Accept: 'application/json' },
                        cache: 'no-store'
                    });
                    if (!response.ok) throw new Error(`Refresh failed (${response.status})`);
                    const data = await response.json();

                    balance.textContent = data.balance;
                    threshold.textContent = data.low_balance_threshold;
                    alert.hidden = !data.low_balance;
                    list.replaceChildren(...data.transactions.map((transaction) => {
                        const item = document.createElement('li');
                        item.textContent = `${transaction.type}: $${transaction.amount} — ${new Date(transaction.created_at).toLocaleString()}`;
                        return item;
                    }));
                    pollError.textContent = '';
                } catch (error) {
                    pollError.textContent = 'Unable to refresh account information. Retrying shortly.';
                    console.error(error);
                }
            }

            function updateTransferFields() {
                const transfer = type.value === 'transfer';
                destinationWrap.hidden = !transfer;
                destination.required = transfer;
            }

            picker.addEventListener('change', () => {
                document.querySelector('#form-account-id').value = picker.value;
                for (const option of destination.options) {
                    option.disabled = option.value === picker.value;
                }
                refresh();
            });
            type.addEventListener('change', updateTransferFields);
            updateTransferFields();
            for (const option of destination.options) {
                option.disabled = option.value === picker.value;
            }

            document.querySelector('#transaction-form').addEventListener('submit', async (event) => {
                event.preventDefault();
                const message = document.querySelector('#form-message');
                message.textContent = '';
                try {
                    const response = await fetch(event.currentTarget.action, {
                        method: 'POST',
                        headers: {
                            Accept: 'application/json',
                            'X-CSRF-TOKEN': csrf
                        },
                        body: new FormData(event.currentTarget)
                    });
                    const result = await response.json();
                    if (!response.ok) {
                        const errors = Object.values(result.errors || {}).flat();
                        throw new Error(errors.join(' ') || result.message || 'Transaction failed.');
                    }
                    message.textContent = result.message;
                    event.currentTarget.reset();
                    document.querySelector('#form-account-id').value = picker.value;
                    updateTransferFields();
                    refresh();
                } catch (error) {
                    message.textContent = error.message;
                }
            });

            refresh();
            window.setInterval(refresh, 5000);
        })();
    </script>
</body>
</html>
